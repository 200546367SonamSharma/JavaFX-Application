package com.example.assignment3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Add {

    @FXML
    private TextField employeeNumber;

    @FXML
    private TextField employeeName;

    @FXML
    private TextField employeeAddress;

    @FXML
    private TextField employeePhone;

    @FXML
    private TextField departmentNumber;

    @FXML
    private TextField departmentName;

    @FXML
    private TextField salary;

    @FXML
    private void addEmployee(ActionEvent event) {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/employees", "root", "")) {

            String SQL_INSERT = "INSERT INTO employee (Emp_NO, Emp_Name, Emp_Add, Emp_Phone, Dept_No, Dept_Name, Salary) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement preparedStatement = conn.prepareStatement(SQL_INSERT);
            preparedStatement.setInt(1, Integer.parseInt(employeeNumber.getText()));
            preparedStatement.setString(2, employeeName.getText());
            preparedStatement.setString(3, employeeAddress.getText());
            preparedStatement.setString(4, employeePhone.getText());
            preparedStatement.setInt(5, Integer.parseInt(departmentNumber.getText()));
            preparedStatement.setString(6, departmentName.getText());
            preparedStatement.setDouble(7, Double.parseDouble(salary.getText()));

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessAlert("Employee added successfully.");
            } else {
                showErrorAlert("Failed to add employee.");
            }
        } catch (SQLException e) {
            showErrorAlert("Error while adding employee:\n" + e.getMessage());
        }
    }

    private void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Add Employee");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

