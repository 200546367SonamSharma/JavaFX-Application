package com.example.assignment3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Update {

    @FXML
    private TextField employeeId;

    @FXML
    private TextField salaryIncrement;

    @FXML
    private void updateSalary(ActionEvent event) {
        try (Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/employees", "root", "")) {

            int empId = Integer.parseInt(employeeId.getText());
            double increment = Double.parseDouble(salaryIncrement.getText());

            String SQL_UPDATE = "UPDATE employee SET Salary = Salary + ? WHERE Emp_NO = ?";

            PreparedStatement preparedStatement = conn.prepareStatement(SQL_UPDATE);
            preparedStatement.setDouble(1, increment);
            preparedStatement.setInt(2, empId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                showSuccessAlert("Salary updated successfully.");
            } else {
                showErrorAlert("Failed to update salary. Employee not found.");
            }
        } catch (SQLException e) {
            showErrorAlert("Error while updating salary:\n" + e.getMessage());
        } catch (NumberFormatException e) {
            showErrorAlert("Invalid input. Please enter valid numbers.");
        }
    }

    private void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Update Salary");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

